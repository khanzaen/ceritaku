<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ViewSeeder extends Seeder
{
    public function run()
    {
        // Views table adalah kosong di database backup
        // Data views akan ditambahkan secara dinamis ketika user membaca story/chapter
    }
}
