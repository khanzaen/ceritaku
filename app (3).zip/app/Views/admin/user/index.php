<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 class="font-semibold text-gray-800 flex items-center gap-2">
            <span class="material-symbols-outlined text-indigo-500 text-xl">group</span>
            Daftar User
        </h3>
        <div class="relative">
            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-base">search</span>
            <input type="text" id="searchInput" placeholder="Cari user..."
                class="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-300 w-64">
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm" id="usersTable">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-5 py-3 text-left font-medium w-10">#</th>
                    <th class="px-5 py-3 text-left font-medium">User</th>
                    <th class="px-5 py-3 text-left font-medium">Email</th>
                    <th class="px-5 py-3 text-left font-medium">Role</th>
                    <th class="px-5 py-3 text-left font-medium">Status</th>
                    <th class="px-5 py-3 text-left font-medium">Bergabung</th>
                    <th class="px-5 py-3 text-center font-medium">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $i => $user): ?>
                        <?php
                            $role     = strtoupper($user['role'] ?? 'USER');
                            $verified = (bool)($user['is_verified'] ?? false);
                            $isSelf   = ($user['id'] == session()->get('user_id'));
                        ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <div class="flex items-center gap-3">
                                    <?php if (!empty($user['profile_photo'])): ?>
                                        <img src="<?= base_url('uploads/' . $user['profile_photo']) ?>"
                                             class="w-8 h-8 rounded-full object-cover flex-shrink-0"
                                             onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'">
                                        <div class="w-8 h-8 rounded-full bg-indigo-100 hidden items-center justify-center text-indigo-700 font-bold text-xs flex-shrink-0">
                                            <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs flex-shrink-0">
                                            <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="min-w-0">
                                        <p class="font-medium text-gray-800 truncate max-w-[130px]"><?= esc($user['name']) ?></p>
                                        <?php if (!empty($user['username'])): ?>
                                            <p class="text-xs text-gray-400">@<?= esc($user['username']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-5 py-3 text-gray-500 truncate max-w-[160px]"><?= esc($user['email']) ?></td>
                            <td class="px-5 py-3">
                                <!-- Change role inline -->
                                <form action="<?= base_url('/admin/users/role/' . $user['id']) ?>" method="POST">
                                    <?= csrf_field() ?>
                                    <select name="role" onchange="this.form.submit()"
                                        class="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-300 <?= $role === 'ADMIN' ? 'text-purple-700 bg-purple-50' : 'text-gray-600 bg-gray-50' ?>"
                                        <?= $isSelf ? 'disabled title="Tidak dapat mengubah role sendiri"' : '' ?>>
                                        <option value="USER"  <?= $role === 'USER'  ? 'selected' : '' ?>>USER</option>
                                        <option value="ADMIN" <?= $role === 'ADMIN' ? 'selected' : '' ?>>ADMIN</option>
                                    </select>
                                </form>
                            </td>
                            <td class="px-5 py-3">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold <?= $verified ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700' ?>">
                                    <?= $verified ? 'Verified' : 'Unverified' ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                <?= date('d M Y', strtotime($user['created_at'])) ?>
                            </td>
                            <td class="px-5 py-3">
                                <div class="flex items-center justify-center gap-1">
                                    <?php if (!$verified): ?>
                                        <form action="<?= base_url('/admin/users/verify/' . $user['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" title="Verifikasi user"
                                                class="p-1.5 rounded-lg text-green-600 hover:bg-green-50 transition"
                                                onclick="return confirm('Verifikasi akun user ini?')">
                                                <span class="material-symbols-outlined text-base">verified_user</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (!$isSelf): ?>
                                        <form action="<?= base_url('/admin/users/delete/' . $user['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" title="Hapus user"
                                                class="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                                                onclick="return confirm('Hapus user <?= esc($user['name']) ?>? Tindakan ini tidak dapat dibatalkan.')">
                                                <span class="material-symbols-outlined text-base">delete</span>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 text-xs text-gray-300 italic">Anda</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="px-5 py-14 text-center">
                            <span class="material-symbols-outlined text-5xl text-gray-200 block mb-2">group</span>
                            <p class="text-gray-400 text-sm">Belum ada user terdaftar</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-6 py-3 bg-gray-50 text-xs text-gray-400 border-t border-gray-100">
        Total: <span class="font-semibold text-gray-600"><?= count($users ?? []) ?></span> user
    </div>
</div>

<script>
    document.getElementById('searchInput').addEventListener('input', function () {
        const q = this.value.toLowerCase();
        document.querySelectorAll('#usersTable tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
</script>

<?= $this->endSection() ?>
