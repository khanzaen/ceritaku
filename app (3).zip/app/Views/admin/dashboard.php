<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<!-- Stats Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
        <div class="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-indigo-600 text-2xl" title="Total Users">group</span>
        </div>
        <div>
            <p class="text-xs text-gray-400 font-medium uppercase tracking-wide">Total Pengguna</p>
            <p class="text-2xl font-bold text-gray-800"><?= number_format($total_users ?? 0) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
        <div class="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-purple-600 text-2xl" title="Total Stories">menu_book</span>
        </div>
        <div>
            <p class="text-xs text-gray-400 font-medium uppercase tracking-wide">Total Cerita</p>
            <p class="text-2xl font-bold text-gray-800"><?= number_format($total_stories ?? 0) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
        <div class="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-green-600 text-2xl" title="Published">check_circle</span>
        </div>
        <div>
            <p class="text-xs text-gray-400 font-medium uppercase tracking-wide">Diterbitkan</p>
            <p class="text-2xl font-bold text-gray-800"><?= number_format($total_published ?? 0) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
        <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-amber-600 text-2xl" title="Pending Review">pending</span>
        </div>
        <div>
            <p class="text-xs text-gray-400 font-medium uppercase tracking-wide">Menunggu Review</p>
            <p class="text-2xl font-bold text-gray-800"><?= number_format($total_pending ?? 0) ?></p>
        </div>
    </div>

</div>

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">

    <!-- Latest Stories -->
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="font-semibold text-gray-800 flex items-center gap-2">
                <span class="material-symbols-outlined text-purple-500 text-xl">menu_book</span>
                Cerita Terbaru
            </h3>
            <a href="<?= base_url('/admin/stories') ?>" class="text-xs text-indigo-600 hover:underline font-medium" title="Lihat semua cerita">Lihat semua →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                        <th class="px-5 py-3 text-left font-medium">Judul</th>
                        <th class="px-5 py-3 text-left font-medium">Status</th>
                        <th class="px-5 py-3 text-left font-medium">Tanggal</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php if (!empty($latest_stories)): ?>
                        <?php foreach ($latest_stories as $story): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-5 py-3 font-medium text-gray-800 max-w-[180px]">
                                    <span class="block truncate" title="<?= esc($story['title']) ?>"><?= esc($story['title']) ?></span>
                                </td>
                                <td class="px-5 py-3">
                                    <?php
                                        $status = $story['status'] ?? 'DRAFT';
                                        $statusColors = [
                                            'PUBLISHED'      => 'bg-green-100 text-green-700',
                                            'PENDING_REVIEW' => 'bg-amber-100 text-amber-700',
                                            'DRAFT'          => 'bg-gray-100 text-gray-500',
                                            'ARCHIVED'       => 'bg-red-100 text-red-600',
                                            'REJECTED'       => 'bg-rose-100 text-rose-600',
                                        ];
                                        $statusColor = $statusColors[$status] ?? 'bg-gray-100 text-gray-500';
                                        $statusLabel = ucfirst(strtolower(str_replace('_', ' ', $status)));
                                    ?>
                                    <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $statusColor ?>"><?= esc($statusLabel) ?></span>
                                </td>
                                <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                    <?= !empty($story['created_at']) ? date('d M Y', strtotime($story['created_at'])) : '-' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="px-5 py-8 text-center text-gray-400 text-sm">Belum ada cerita</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Latest Users -->
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="font-semibold text-gray-800 flex items-center gap-2">
                <span class="material-symbols-outlined text-indigo-500 text-xl">group</span>
                Pengguna Terbaru
            </h3>
            <a href="<?= base_url('/admin/users') ?>" class="text-xs text-indigo-600 hover:underline font-medium" title="Lihat semua pengguna">Lihat semua →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                        <th class="px-5 py-3 text-left font-medium">Nama</th>
                        <th class="px-5 py-3 text-left font-medium">Email</th>
                        <th class="px-5 py-3 text-left font-medium">Bergabung</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php if (!empty($latest_users)): ?>
                        <?php
                            // Warna avatar dinamis berdasarkan huruf pertama nama
                            $avatarColors = [
                                'bg-indigo-100 text-indigo-700',
                                'bg-purple-100 text-purple-700',
                                'bg-pink-100 text-pink-700',
                                'bg-green-100 text-green-700',
                                'bg-amber-100 text-amber-700',
                                'bg-teal-100 text-teal-700',
                                'bg-sky-100 text-sky-700',
                            ];
                        ?>
                        <?php foreach ($latest_users as $index => $user): ?>
                            <?php
                                $name       = $user['name'] ?? 'User';
                                $initial    = strtoupper(substr($name, 0, 1));
                                $colorClass = $avatarColors[ord($initial) % count($avatarColors)];
                            ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-5 py-3">
                                    <div class="flex items-center gap-2">
                                        <div class="w-7 h-7 rounded-full <?= $colorClass ?> flex items-center justify-center font-bold text-xs flex-shrink-0" title="<?= esc($name) ?>">
                                            <?= esc($initial) ?>
                                        </div>
                                        <span class="font-medium text-gray-800 truncate max-w-[110px]" title="<?= esc($name) ?>"><?= esc($name) ?></span>
                                    </div>
                                </td>
                                <td class="px-5 py-3 text-gray-500 max-w-[150px]">
                                    <span class="block truncate" title="<?= esc($user['email'] ?? '') ?>"><?= esc($user['email'] ?? '-') ?></span>
                                </td>
                                <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                    <?= !empty($user['created_at']) ? date('d M Y', strtotime($user['created_at'])) : '-' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="px-5 py-8 text-center text-gray-400 text-sm">Belum ada pengguna</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?= $this->endSection() ?>