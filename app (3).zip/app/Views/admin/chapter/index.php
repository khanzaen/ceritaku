<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 class="font-semibold text-gray-800 flex items-center gap-2">
            <span class="material-symbols-outlined text-blue-500 text-xl">article</span>
            Daftar Chapter
        </h3>
        <div class="relative">
            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-base">search</span>
            <input type="text" id="searchInput" placeholder="Cari chapter..."
                class="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-300 w-64">
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm" id="chaptersTable">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-5 py-3 text-left font-medium w-10">#</th>
                    <th class="px-5 py-3 text-left font-medium">Judul Chapter</th>
                    <th class="px-5 py-3 text-left font-medium">Story</th>
                    <th class="px-5 py-3 text-left font-medium">Penulis</th>
                    <th class="px-5 py-3 text-left font-medium">Tanggal</th>
                    <th class="px-5 py-3 text-center font-medium">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if (!empty($chapters)): ?>
                    <?php foreach ($chapters as $i => $chapter): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <p class="font-medium text-gray-800 truncate max-w-[200px]"><?= esc($chapter['title']) ?></p>
                            </td>
                            <td class="px-5 py-3 text-gray-600 max-w-[160px] truncate"><?= esc($chapter['story_title'] ?? '-') ?></td>
                            <td class="px-5 py-3 text-gray-500"><?= esc($chapter['author_name'] ?? '-') ?></td>
                            <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                <?= date('d M Y', strtotime($chapter['created_at'])) ?>
                            </td>
                            <td class="px-5 py-3">
                                <div class="flex items-center justify-center">
                                    <form action="<?= base_url('/admin/chapters/delete/' . $chapter['id']) ?>" method="POST" class="inline">
                                        <?= csrf_field() ?>
                                        <button type="submit" title="Hapus"
                                            class="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                                            onclick="return confirm('Hapus chapter ini? Tindakan ini tidak dapat dibatalkan.')">
                                            <span class="material-symbols-outlined text-base">delete</span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="px-5 py-14 text-center">
                            <span class="material-symbols-outlined text-5xl text-gray-200 block mb-2">article</span>
                            <p class="text-gray-400 text-sm">Belum ada chapter</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-6 py-3 bg-gray-50 text-xs text-gray-400 border-t border-gray-100">
        Total: <span class="font-semibold text-gray-600"><?= count($chapters ?? []) ?></span> chapter
    </div>
</div>

<script>
    document.getElementById('searchInput').addEventListener('input', function () {
        const q = this.value.toLowerCase();
        document.querySelectorAll('#chaptersTable tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
</script>

<?= $this->endSection() ?>
