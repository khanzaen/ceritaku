<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Admin Panel') ?> – CeritaKu Admin</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: { DEFAULT: '#6c5ce7', dark: '#5a4bd1' },
                    }
                }
            }
        }
    </script>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; }

        /* ── Sidebar base ── */
        #admin-sidebar {
            background: #ffffff;
            border-right: 1px solid #ede9fe;
            transition: transform 0.35s cubic-bezier(.4,0,.2,1);
            box-shadow: 4px 0 24px rgba(108,92,231,0.06);
        }

        /* Subtle top accent bar */
        #admin-sidebar .brand-section {
            position: relative;
        }
        #admin-sidebar .brand-section::after {
            content: '';
            position: absolute;
            bottom: 0; left: 16px; right: 16px;
            height: 1px;
            background: linear-gradient(90deg, transparent, #ede9fe, transparent);
        }

        /* Nav links */
        .nav-link {
            border-left: 2px solid transparent;
            transition: all 0.18s ease;
            position: relative;
            overflow: hidden;
        }
        .nav-link:hover {
            border-left-color: rgba(108,92,231,0.4);
            background: #f5f3ff;
            color: #5b21b6;
        }
        .nav-link:hover .nav-icon { color: #7c3aed; }
        .nav-link.active {
            border-left-color: #6c5ce7;
            background: linear-gradient(90deg, #ede9fe, #f5f3ff);
            color: #5b21b6;
        }
        .nav-link.active .nav-icon { color: #6c5ce7; }

        /* Section label */
        .nav-section-label {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.12em;
            color: #c4b5fd;
            text-transform: uppercase;
            padding: 0 12px;
            margin: 20px 0 6px;
        }

        /* Scrollbar */
        #admin-sidebar::-webkit-scrollbar { width: 3px; }
        #admin-sidebar::-webkit-scrollbar-thumb { background: #ddd6fe; border-radius: 4px; }

        /* Mobile */
        @media (max-width: 1023px) {
            #admin-sidebar { transform: translateX(-100%); position: fixed; }
            #admin-sidebar.open { transform: translateX(0); }
        }

        /* Topbar */
        #topbar {
            backdrop-filter: blur(12px);
            background: rgba(255,255,255,0.92);
            border-bottom: 1px solid rgba(0,0,0,0.06);
        }

        /* Flash messages */
        .flash-success { background: linear-gradient(90deg, #f0fdf4, #dcfce7); border-color: #86efac; }
        .flash-error   { background: linear-gradient(90deg, #fef2f2, #fee2e2); border-color: #fca5a5; }

        /* Main content scrollbar */
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 99px; }
        ::-webkit-scrollbar-thumb:hover { background: #9ca3af; }
    </style>
</head>
<body class="h-full bg-[#f5f4f9]">

<!-- Mobile Overlay -->
<div id="sidebar-overlay"
     class="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden hidden transition-opacity"
     onclick="closeSidebar()"></div>

<!-- ═══════════════════════ SIDEBAR ═══════════════════════ -->
<aside id="admin-sidebar"
       class="fixed top-0 left-0 h-full w-64 text-gray-700 z-40 flex flex-col overflow-y-auto">

    <!-- Brand -->
    <div class="brand-section flex items-center justify-center px-6 py-6 flex-shrink-0">
        <img src="<?= base_url('assets/images/logo.png') ?>"
             alt="CeritaKu"
             class="h-14 object-contain"
             onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'">
        <!-- Fallback wordmark -->
        <div style="display:none" class="items-center gap-2">
            <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center shadow-lg shadow-purple-900/40">
                <span class="material-symbols-rounded text-white text-base" style="font-variation-settings:'FILL' 1">auto_stories</span>
            </div>
            <span class="text-base font-extrabold tracking-tight text-gray-800">Cerita<span class="text-violet-400">Ku</span></span>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 px-3 pb-4">

        <p class="nav-section-label">Main Menu</p>

        <a href="<?= base_url('/admin/dashboard') ?>"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5
                  <?= (uri_string() === 'admin/dashboard') ? 'active' : '' ?>">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400"
                  style="font-variation-settings:'FILL' 1">dashboard</span>
            Dashboard
        </a>

        <p class="nav-section-label">Konten</p>

        <a href="<?= base_url('/admin/stories') ?>"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5
                  <?= str_contains(uri_string(), 'admin/stories') ? 'active' : '' ?>">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400"
                  style="font-variation-settings:'FILL' 1">menu_book</span>
            Story Management
        </a>

        <a href="<?= base_url('/admin/chapters') ?>"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5
                  <?= str_contains(uri_string(), 'admin/chapters') ? 'active' : '' ?>">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400"
                  style="font-variation-settings:'FILL' 1">article</span>
            Chapter Management
        </a>

        <a href="<?= base_url('/admin/reviews') ?>"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5
                  <?= str_contains(uri_string(), 'admin/reviews') ? 'active' : '' ?>">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400"
                  style="font-variation-settings:'FILL' 1">rate_review</span>
            Review Management
        </a>

        <p class="nav-section-label">Pengguna</p>

        <a href="<?= base_url('/admin/users') ?>"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5
                  <?= str_contains(uri_string(), 'admin/users') ? 'active' : '' ?>">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400"
                  style="font-variation-settings:'FILL' 1">group</span>
            User Management
        </a>

        <p class="nav-section-label">Sistem</p>

        <a href="<?= base_url('/') ?>" target="_blank"
           class="nav-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 mb-0.5">
            <span class="nav-icon material-symbols-rounded text-xl text-violet-400">open_in_new</span>
            Lihat Website
        </a>
    </nav>

    <!-- User card + Logout -->
    <div class="px-3 py-4 flex-shrink-0" style="border-top: 1px solid #ede9fe">
        <!-- User info mini card -->
        <div class="flex items-center gap-3 px-3 py-2.5 mb-2 rounded-xl"
             style="background: #f5f3ff">
            <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 text-white"
                 style="background: linear-gradient(135deg,#6c5ce7,#a855f7)">
                <?= strtoupper(substr(session()->get('user_name') ?? 'A', 0, 1)) ?>
            </div>
            <div class="min-w-0">
                <p class="text-sm font-semibold text-gray-800 truncate">
                    <?= esc(session()->get('user_name') ?? 'Admin') ?>
                </p>
                <p class="text-[11px] text-violet-500 font-medium">Administrator</p>
            </div>
        </div>

        <!-- Logout -->
        <form action="<?= base_url('/auth/logout') ?>" method="POST">
            <?= csrf_field() ?>
            <button type="submit"
                class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:text-red-600 transition-all"
                style="border: 1px solid #fecaca; background: #fff5f5;"
                onmouseover="this.style.background='#fee2e2'"
                onmouseout="this.style.background='#fff5f5'">
                <span class="material-symbols-rounded text-xl">logout</span>
                Logout
            </button>
        </form>
    </div>
</aside>

<!-- ═══════════════════════ MAIN WRAPPER ═══════════════════════ -->
<div class="lg:ml-64 flex flex-col min-h-screen">

    <!-- Top Bar -->
    <header id="topbar" class="sticky top-0 z-20 shadow-sm">
        <div class="flex items-center justify-between px-4 lg:px-6 h-16">

            <!-- Mobile toggle -->
            <button onclick="toggleSidebar()"
                    class="lg:hidden p-2 rounded-xl hover:bg-gray-100 transition text-gray-600">
                <span class="material-symbols-rounded">menu</span>
            </button>

            <!-- Breadcrumb / title -->
            <div class="flex items-center gap-2">
                <span class="text-xs text-gray-400 hidden sm:block">Admin</span>
                <span class="text-xs text-gray-300 hidden sm:block">/</span>
                <h2 class="font-bold text-gray-800 text-base"><?= esc($title ?? 'Dashboard') ?></h2>
            </div>

            <!-- Right actions -->
            <div class="flex items-center gap-2">
                <!-- Notification -->
                <button class="relative p-2.5 rounded-xl hover:bg-gray-100 transition text-gray-500 hover:text-gray-700">
                    <span class="material-symbols-rounded text-xl">notifications</span>
                    <span class="absolute top-2 right-2 w-1.5 h-1.5 bg-red-500 rounded-full ring-2 ring-white"></span>
                </button>

                <!-- Divider -->
                <div class="w-px h-6 bg-gray-200 mx-1"></div>

                <!-- User avatar -->
                <div class="flex items-center gap-2.5 pl-1">
                    <div class="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-md"
                         style="background: linear-gradient(135deg,#6c5ce7,#a855f7)">
                        <?= strtoupper(substr(session()->get('user_name') ?? 'A', 0, 1)) ?>
                    </div>
                    <div class="hidden sm:block">
                        <p class="text-sm font-semibold text-gray-800 leading-none">
                            <?= esc(session()->get('user_name') ?? 'Admin') ?>
                        </p>
                        <p class="text-[11px] text-violet-500 font-medium mt-0.5">Administrator</p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <main class="flex-1 p-4 lg:p-6">

        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-success mb-5 px-4 py-3 rounded-xl border flex items-center gap-2.5 text-green-700 text-sm font-medium">
                <span class="material-symbols-rounded text-green-500" style="font-variation-settings:'FILL' 1">check_circle</span>
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-error mb-5 px-4 py-3 rounded-xl border flex items-center gap-2.5 text-red-600 text-sm font-medium">
                <span class="material-symbols-rounded text-red-500" style="font-variation-settings:'FILL' 1">error</span>
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <?= $this->renderSection('content') ?>
    </main>

    <!-- Footer -->
    <?= $this->include('layouts/admin/footer') ?>
</div>

<script>
    function toggleSidebar() {
        document.getElementById('admin-sidebar').classList.toggle('open');
        document.getElementById('sidebar-overlay').classList.toggle('hidden');
    }
    function closeSidebar() {
        document.getElementById('admin-sidebar').classList.remove('open');
        document.getElementById('sidebar-overlay').classList.add('hidden');
    }

    // Auto set active link based on current path
    const path = window.location.pathname;
    document.querySelectorAll('.nav-link[href]').forEach(link => {
        const href = link.getAttribute('href');
        if (href && href !== '/' && path.includes(href.split('/').pop())) {
            link.classList.add('active');
        }
    });
</script>
</body>
</html>