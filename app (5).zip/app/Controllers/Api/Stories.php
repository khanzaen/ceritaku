<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Stories extends BaseController
{
    public function index()
    {
        //
    }
}
