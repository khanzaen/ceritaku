<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<!-- ═══════════════════ TOAST CONTAINER ═══════════════════ -->
<div id="toast-container" class="fixed top-6 right-6 z-50 flex flex-col gap-2 pointer-events-none"></div>

<style>
@keyframes toast-in {
    0%   { opacity: 0; transform: translateX(110%); }
    100% { opacity: 1; transform: translateX(0); }
}
@keyframes toast-out {
    0%   { opacity: 1; transform: translateX(0); }
    100% { opacity: 0; transform: translateX(110%); }
}
.toast {
    pointer-events: all;
    animation: toast-in 0.35s cubic-bezier(.4,0,.2,1) forwards;
}
.toast.hiding {
    animation: toast-out 0.3s cubic-bezier(.4,0,.2,1) forwards;
}
</style>

<script>
function showToast(message, type = 'success', detail = '') {
    const cfg = {
        success: { bg: 'bg-green-50',  border: 'border-green-200',  text: 'text-green-700',  icon: 'check_circle',  iconColor: 'text-green-500'  },
        error:   { bg: 'bg-red-50',    border: 'border-red-200',    text: 'text-red-700',    icon: 'error',         iconColor: 'text-red-500'    },
        warning: { bg: 'bg-amber-50',  border: 'border-amber-200',  text: 'text-amber-700',  icon: 'warning',       iconColor: 'text-amber-500'  },
        info:    { bg: 'bg-indigo-50', border: 'border-indigo-200', text: 'text-indigo-700', icon: 'info',          iconColor: 'text-indigo-500' },
    };
    const c = cfg[type] ?? cfg.success;
    const toast = document.createElement('div');
    toast.className = `toast ${c.bg} ${c.border} border rounded-xl shadow-lg px-4 py-3 flex items-start gap-3 min-w-[280px] max-w-sm`;
    toast.innerHTML = `
        <span class="material-symbols-outlined ${c.iconColor} text-xl flex-shrink-0 mt-0.5" style="font-variation-settings:'FILL' 1">${c.icon}</span>
        <div class="flex-1 min-w-0">
            <p class="${c.text} text-sm font-semibold leading-snug">${message}</p>
            ${detail ? `<p class="${c.text} text-xs opacity-70 mt-0.5">${detail}</p>` : ''}
        </div>
        <button onclick="dismissToast(this.parentElement)" class="${c.text} opacity-50 hover:opacity-100 transition text-lg leading-none flex-shrink-0 mt-0.5">&times;</button>
    `;
    document.getElementById('toast-container').appendChild(toast);
    setTimeout(() => dismissToast(toast), 4000);
}

function dismissToast(el) {
    if (!el || el.classList.contains('hiding')) return;
    el.classList.add('hiding');
    setTimeout(() => el.remove(), 300);
}

<?php if (session()->getFlashdata('success')): ?>
window.addEventListener('DOMContentLoaded', () => {
    showToast(<?= json_encode(session()->getFlashdata('success')) ?>, 'success', 'The action was completed successfully.');
});
<?php endif; ?>
<?php if (session()->getFlashdata('error')): ?>
window.addEventListener('DOMContentLoaded', () => {
    showToast(<?= json_encode(session()->getFlashdata('error')) ?>, 'error', 'Something went wrong. Please try again.');
});
<?php endif; ?>
<?php if (session()->getFlashdata('warning')): ?>
window.addEventListener('DOMContentLoaded', () => {
    showToast(<?= json_encode(session()->getFlashdata('warning')) ?>, 'warning');
});
<?php endif; ?>
</script>

<!-- ═══════════════════ CONFIRM MODAL ═══════════════════ -->
<div id="confirm-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 backdrop-blur-sm">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6">
        <div class="flex items-start gap-3 mb-5">
            <div id="modal-icon-wrap" class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
                <span id="modal-icon" class="material-symbols-outlined text-xl" style="font-variation-settings:'FILL' 1"></span>
            </div>
            <div class="flex-1">
                <p id="modal-title" class="font-semibold text-gray-800 text-base"></p>
                <p id="modal-body"  class="text-sm text-gray-500 mt-1 leading-relaxed"></p>
            </div>
        </div>
        <div class="flex justify-end gap-2">
            <button onclick="closeModal()" class="px-4 py-2 text-sm rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition">Cancel</button>
            <button id="modal-confirm-btn" class="px-4 py-2 text-sm rounded-xl font-semibold text-white transition"></button>
        </div>
    </div>
</div>

<script>
let _pendingForm = null;

const modalConfigs = {
    approve: {
        title:     'Publish Story',
        body:      'This story will be published and become visible to all readers immediately.',
        icon:      'check_circle',
        iconBg:    'bg-green-100',
        iconColor: 'text-green-600',
        btnBg:     'bg-green-600 hover:bg-green-700',
        btnLabel:  'Yes, Publish',
        toast:     ['Story published successfully.', 'success', 'The story is now live and visible to readers.'],
    },
    archive: {
        title:     'Archive Story',
        body:      'This story will be hidden from all readers. You can restore it later from the archived list.',
        icon:      'archive',
        iconBg:    'bg-amber-100',
        iconColor: 'text-amber-600',
        btnBg:     'bg-amber-500 hover:bg-amber-600',
        btnLabel:  'Yes, Archive',
        toast:     ['Story archived.', 'warning', 'The story is now hidden from readers.'],
    },
    delete: {
        title:     'Delete Story Permanently',
        body:      'This will permanently delete the story and ALL its chapters. This action cannot be undone.',
        icon:      'delete_forever',
        iconBg:    'bg-red-100',
        iconColor: 'text-red-600',
        btnBg:     'bg-red-600 hover:bg-red-700',
        btnLabel:  'Yes, Delete',
        toast:     ['Story deleted permanently.', 'error', 'The story and all its chapters have been removed.'],
    },
};

function openModal(form, type) {
    _pendingForm = form;
    const cfg = modalConfigs[type];
    document.getElementById('modal-title').textContent   = cfg.title;
    document.getElementById('modal-body').textContent    = cfg.body;
    document.getElementById('modal-icon').textContent    = cfg.icon;
    document.getElementById('modal-icon-wrap').className = `w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${cfg.iconBg}`;
    document.getElementById('modal-icon').className      = `material-symbols-outlined text-xl ${cfg.iconColor}`;
    const btn = document.getElementById('modal-confirm-btn');
    btn.textContent = cfg.btnLabel;
    btn.className   = `px-4 py-2 text-sm rounded-xl font-semibold text-white transition ${cfg.btnBg}`;
    btn.onclick     = () => {
        const t = cfg.toast;
        closeModal();
        showToast(t[0], t[1], t[2]);
        setTimeout(() => form.submit(), 350);
    };
    const modal = document.getElementById('confirm-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeModal() {
    const modal = document.getElementById('confirm-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    _pendingForm = null;
}

document.getElementById('confirm-modal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>

<!-- ═══════════════════ STATS CARDS ═══════════════════ -->
<?php
    $stories       = $stories ?? [];
    $statTotal     = count($stories);
    $statPublished = count(array_filter($stories, fn($s) => ($s['status'] ?? '') === 'PUBLISHED'));
    $statPending   = count(array_filter($stories, fn($s) => ($s['status'] ?? '') === 'PENDING_REVIEW'));
    $statDraft     = count(array_filter($stories, fn($s) => ($s['status'] ?? '') === 'DRAFT'));
    $statArchived  = count(array_filter($stories, fn($s) => ($s['status'] ?? '') === 'ARCHIVED'));
    $statFeatured  = count(array_filter($stories, fn($s) => !empty($s['is_featured'])));
?>
<div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-purple-600 text-xl" style="font-variation-settings:'FILL' 1">menu_book</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Total</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statTotal) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-green-600 text-xl" style="font-variation-settings:'FILL' 1">check_circle</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Published</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statPublished) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-amber-600 text-xl" style="font-variation-settings:'FILL' 1">pending</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Pending</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statPending) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-gray-500 text-xl" style="font-variation-settings:'FILL' 1">draft</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Draft</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statDraft) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-red-500 text-xl" style="font-variation-settings:'FILL' 1">archive</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Archived</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statArchived) ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center flex-shrink-0">
            <span class="material-symbols-outlined text-indigo-600 text-xl" style="font-variation-settings:'FILL' 1">star</span>
        </div>
        <div>
            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wide leading-tight">Featured</p>
            <p class="text-xl font-bold text-gray-800"><?= number_format($statFeatured) ?></p>
        </div>
    </div>

</div>

<!-- ═══════════════════ MAIN TABLE ═══════════════════ -->
<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 class="font-semibold text-gray-800 flex items-center gap-2 flex-shrink-0">
            <span class="material-symbols-outlined text-purple-500 text-xl">menu_book</span>
            Story Management
        </h3>

        <div class="flex items-center gap-2 flex-wrap">
            <!-- Status Filter -->
            <select id="filterStatus"
                class="text-sm border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-gray-50 text-gray-600">
                <option value="">All Status</option>
                <option value="PUBLISHED">Published</option>
                <option value="PENDING_REVIEW">Pending Review</option>
                <option value="DRAFT">Draft</option>
                <option value="ARCHIVED">Archived</option>
            </select>

            <!-- Publication Filter -->
            <select id="filterPublication"
                class="text-sm border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-gray-50 text-gray-600">
                <option value="">All Publication</option>
                <option value="1">Published</option>
                <option value="0">Unpublished</option>
            </select>

            <!-- Featured Filter -->
            <select id="filterFeatured"
                class="text-sm border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-gray-50 text-gray-600">
                <option value="">All Featured</option>
                <option value="1">Featured</option>
                <option value="0">Not Featured</option>
            </select>

            <!-- Search -->
            <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-base">search</span>
                <input type="text" id="searchInput" placeholder="Search stories..."
                    class="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-300 w-56">
            </div>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-sm" id="storiesTable">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-5 py-3 text-left font-medium w-10">#</th>
                    <th class="px-5 py-3 text-left font-medium">Title</th>
                    <th class="px-5 py-3 text-left font-medium">Author</th>
                    <th class="px-5 py-3 text-left font-medium">Status</th>
                    <th class="px-5 py-3 text-left font-medium">Featured</th>
                    <th class="px-5 py-3 text-left font-medium">Date</th>
                    <th class="px-5 py-3 text-center font-medium">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if (!empty($stories)): ?>
                    <?php foreach ($stories as $i => $story): ?>
                        <?php
                            $status      = $story['status'] ?? 'DRAFT';
                            $isFeatured  = !empty($story['is_featured']) ? 1 : 0;
                            $isPublished = ($status === 'PUBLISHED') ? 1 : 0;
                            $badgeMap    = [
                                'PUBLISHED'      => 'bg-green-100 text-green-700',
                                'PENDING_REVIEW' => 'bg-amber-100 text-amber-700',
                                'DRAFT'          => 'bg-gray-100 text-gray-500',
                                'ARCHIVED'       => 'bg-red-100 text-red-600',
                            ];
                            $badge       = $badgeMap[$status] ?? 'bg-gray-100 text-gray-500';
                            $statusLabel = ucfirst(strtolower(str_replace('_', ' ', $status)));
                        ?>
                        <tr class="hover:bg-gray-50 transition-colors"
                            data-status="<?= esc($status) ?>"
                            data-featured="<?= $isFeatured ?>"
                            data-publication="<?= $isPublished ?>">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <div class="flex items-center gap-3">
                                    <?php if (!empty($story['cover_image'])): ?>
                                        <img src="<?= base_url('uploads/' . $story['cover_image']) ?>"
                                             class="w-9 h-12 object-cover rounded-md flex-shrink-0"
                                             onerror="this.style.display='none'">
                                    <?php else: ?>
                                        <div class="w-9 h-12 bg-purple-50 rounded-md flex items-center justify-center flex-shrink-0">
                                            <span class="material-symbols-outlined text-purple-300 text-lg">menu_book</span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="min-w-0">
                                        <p class="font-medium text-gray-800 truncate max-w-[200px]" title="<?= esc($story['title']) ?>">
                                            <a href="<?= base_url('/admin/stories/' . $story['id']) ?>" class="hover:text-indigo-600 transition">
                                                <?= esc($story['title']) ?>
                                            </a>
                                        </p>
                                        <?php if (!empty($story['genres'])): ?>
                                            <p class="text-xs text-gray-400 truncate max-w-[180px]"><?= esc($story['genres']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-5 py-3 text-gray-600"><?= esc($story['author_name'] ?? '-') ?></td>
                            <td class="px-5 py-3">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold <?= $badge ?>">
                                    <?= esc($statusLabel) ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-xs">
                                <form action="<?= base_url('/admin/stories/toggle-featured/' . $story['id']) ?>" method="POST" class="inline">
                                    <?= csrf_field() ?>
                                    <select name="is_featured"
                                        class="border border-gray-200 rounded-xl px-2 py-1 text-xs <?= $isFeatured ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'bg-gray-100 text-gray-400' ?>"
                                        onchange="
                                            const label = this.options[this.selectedIndex].text;
                                            showToast('Featured status updated.', 'info', '&quot;<?= esc(addslashes($story['title'])) ?>&quot; marked as ' + label + '.');
                                            this.form.submit();
                                        ">
                                        <option value="1" style="background-color:#e0e7ff;color:#4f46e5;font-weight:bold;" <?= $isFeatured ? 'selected' : '' ?>>Featured</option>
                                        <option value="0" style="background-color:#f3f4f6;color:#6b7280;"                  <?= !$isFeatured ? 'selected' : '' ?>>Not Featured</option>
                                    </select>
                                </form>
                            </td>
                            <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                <?= !empty($story['created_at']) ? date('d M Y', strtotime($story['created_at'])) : '-' ?>
                            </td>
                            <td class="px-5 py-3">
                                <div class="flex items-center justify-center gap-1">

                                    <?php if ($status === 'PENDING_REVIEW'): ?>
                                        <form action="<?= base_url('/admin/stories/approve/' . $story['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="button" title="Approve & Publish"
                                                class="p-1.5 rounded-lg text-green-600 hover:bg-green-50 transition"
                                                onclick="openModal(this.closest('form'), 'approve')">
                                                <span class="material-symbols-outlined text-base">check_circle</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <?php if ($status !== 'ARCHIVED'): ?>
                                        <form action="<?= base_url('/admin/stories/archive/' . $story['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="button" title="Archive"
                                                class="p-1.5 rounded-lg text-amber-500 hover:bg-amber-50 transition"
                                                onclick="openModal(this.closest('form'), 'archive')">
                                                <span class="material-symbols-outlined text-base">archive</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <form action="<?= base_url('/admin/stories/delete/' . $story['id']) ?>" method="POST" class="inline">
                                        <?= csrf_field() ?>
                                        <button type="button" title="Delete"
                                            class="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                                            onclick="openModal(this.closest('form'), 'delete')">
                                            <span class="material-symbols-outlined text-base">delete</span>
                                        </button>
                                    </form>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="px-5 py-14 text-center">
                            <span class="material-symbols-outlined text-5xl text-gray-200 block mb-2">menu_book</span>
                            <p class="text-gray-400 text-sm">No stories found</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="px-6 py-3 bg-gray-50 text-xs text-gray-400 border-t border-gray-100">
        Total: <span class="font-semibold text-gray-600" id="visibleCount"><?= count($stories) ?></span> stories
    </div>
</div>

<script>
    function applyFilters() {
        const q           = document.getElementById('searchInput').value.toLowerCase();
        const status      = document.getElementById('filterStatus').value;
        const publication = document.getElementById('filterPublication').value;
        const featured    = document.getElementById('filterFeatured').value;
        let visible       = 0;

        document.querySelectorAll('#storiesTable tbody tr').forEach(row => {
            const text           = row.textContent.toLowerCase();
            const rowStatus      = row.getAttribute('data-status')      ?? '';
            const rowFeatured    = row.getAttribute('data-featured')    ?? '';
            const rowPublication = row.getAttribute('data-publication') ?? '';

            const matchText        = !q           || text.includes(q);
            const matchStatus      = !status      || rowStatus === status;
            const matchPublication = !publication || rowPublication === publication;
            const matchFeatured    = !featured    || rowFeatured === featured;

            const show = matchText && matchStatus && matchPublication && matchFeatured;
            row.style.display = show ? '' : 'none';
            if (show) visible++;
        });

        document.getElementById('visibleCount').textContent = visible;
    }

    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('filterStatus').addEventListener('change', applyFilters);
    document.getElementById('filterPublication').addEventListener('change', applyFilters);
    document.getElementById('filterFeatured').addEventListener('change', applyFilters);
</script>

<?= $this->endSection() ?>