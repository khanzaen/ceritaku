    <footer class="bg-white border-t border-gray-200 mt-auto">
        <div class="px-4 lg:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p class="text-xs text-gray-500">
                &copy; <?= date('Y') ?> <span class="font-semibold text-[#6c5ce7]">CeritaKu</span>. All rights reserved.
            </p>
        </div>
    </footer>
