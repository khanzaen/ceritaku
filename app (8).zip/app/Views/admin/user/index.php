<?= $this->extend('layouts/admin_layout') ?>
<?= $this->section('content') ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 class="font-semibold text-gray-800 flex items-center gap-2">
            <span class="material-symbols-outlined text-indigo-500 text-xl">group</span>
            User Management
        </h3>
        <div class="flex items-center gap-2 flex-wrap">
            <!-- Role Filter -->
            <select id="filterRole"
                class="text-sm border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-gray-50 text-gray-600">
                <option value="">All Roles</option>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
            <!-- Status Filter -->
            <select id="filterStatus"
                class="text-sm border border-gray-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-gray-50 text-gray-600">
                <option value="">All Status</option>
                <option value="verified">Verified</option>
                <option value="unverified">Unverified</option>
            </select>
            <!-- Search -->
            <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-base">search</span>
                <input type="text" id="searchInput" placeholder="Search users..."
                    class="pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-300 w-52">
            </div>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm" id="usersTable">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-5 py-3 text-left font-medium w-10">#</th>
                    <th class="px-5 py-3 text-left font-medium">User</th>
                    <th class="px-5 py-3 text-left font-medium">Email</th>
                    <th class="px-5 py-3 text-left font-medium">Role</th>
                    <th class="px-5 py-3 text-left font-medium">Status</th>
                    <th class="px-5 py-3 text-left font-medium">Joined</th>
                    <th class="px-5 py-3 text-center font-medium">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if (!empty($users)): ?>
                    <?php
                        $avatarColors = [
                            'bg-indigo-100 text-indigo-700',
                            'bg-purple-100 text-purple-700',
                            'bg-pink-100 text-pink-700',
                            'bg-green-100 text-green-700',
                            'bg-amber-100 text-amber-700',
                            'bg-teal-100 text-teal-700',
                            'bg-sky-100 text-sky-700',
                        ];
                    ?>
                    <?php foreach ($users as $i => $user): ?>
                        <?php
                            $role      = strtoupper($user['role'] ?? 'USER');
                            $verified  = (bool)($user['is_verified'] ?? false);
                            $isSelf    = ($user['id'] == session()->get('user_id'));
                            $name      = $user['name'] ?? 'User';
                            $initial   = strtoupper(substr($name, 0, 1));
                            $colorClass = $avatarColors[ord($initial) % count($avatarColors)];
                        ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-5 py-3 text-gray-400"><?= $i + 1 ?></td>
                            <td class="px-5 py-3">
                                <div class="flex items-center gap-3">
                                    <?php if (!empty($user['profile_photo'])): ?>
                                        <img src="<?= base_url('uploads/' . $user['profile_photo']) ?>"
                                             class="w-8 h-8 rounded-full object-cover flex-shrink-0"
                                             onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'">
                                        <div class="w-8 h-8 rounded-full <?= $colorClass ?> hidden items-center justify-center font-bold text-xs flex-shrink-0">
                                            <?= esc($initial) ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="w-8 h-8 rounded-full <?= $colorClass ?> flex items-center justify-center font-bold text-xs flex-shrink-0">
                                            <?= esc($initial) ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="min-w-0">
                                        <p class="font-medium text-gray-800 truncate max-w-[130px]" title="<?= esc($name) ?>"><?= esc($name) ?></p>
                                        <?php if (!empty($user['username'])): ?>
                                            <p class="text-xs text-gray-400">@<?= esc($user['username']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-5 py-3 text-gray-500 max-w-[160px]">
                                <span class="block truncate" title="<?= esc($user['email'] ?? '') ?>"><?= esc($user['email'] ?? '-') ?></span>
                            </td>
                            <td class="px-5 py-3">
                                <form action="<?= base_url('/admin/users/role/' . $user['id']) ?>" method="POST">
                                    <?= csrf_field() ?>
                                    <select name="role" onchange="this.form.submit()"
                                        class="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-300 <?= $role === 'ADMIN' ? 'text-purple-700 bg-purple-50' : 'text-gray-600 bg-gray-50' ?>"
                                        <?= $isSelf ? 'disabled title="You cannot change your own role"' : '' ?>>
                                        <option value="USER"  <?= $role === 'USER'  ? 'selected' : '' ?>>USER</option>
                                        <option value="ADMIN" <?= $role === 'ADMIN' ? 'selected' : '' ?>>ADMIN</option>
                                    </select>
                                </form>
                            </td>
                            <td class="px-5 py-3">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold <?= $verified ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700' ?>">
                                    <?= $verified ? 'Verified' : 'Unverified' ?>
                                </span>
                            </td>
                            <td class="px-5 py-3 text-gray-400 text-xs whitespace-nowrap">
                                <?= !empty($user['created_at']) ? date('d M Y', strtotime($user['created_at'])) : '-' ?>
                            </td>
                            <td class="px-5 py-3">
                                <div class="flex items-center justify-center gap-1">
                                    <?php if (!$verified): ?>
                                        <form action="<?= base_url('/admin/users/verify/' . $user['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" title="Verify user"
                                                class="p-1.5 rounded-lg text-green-600 hover:bg-green-50 transition"
                                                onclick="return confirm('Verify this user account?')">
                                                <span class="material-symbols-outlined text-base">verified_user</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (!$isSelf): ?>
                                        <form action="<?= base_url('/admin/users/delete/' . $user['id']) ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" title="Delete user"
                                                class="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                                                onclick="return confirm('Delete user <?= esc($user['name']) ?>? This action cannot be undone.')">
                                                <span class="material-symbols-outlined text-base">delete</span>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 text-xs text-gray-300 italic">You</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="px-5 py-14 text-center">
                            <span class="material-symbols-outlined text-5xl text-gray-200 block mb-2">group</span>
                            <p class="text-gray-400 text-sm">No users registered yet</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-6 py-3 bg-gray-50 text-xs text-gray-400 border-t border-gray-100">
        Total: <span class="font-semibold text-gray-600" id="visibleCount"><?= count($users ?? []) ?></span> users
    </div>
</div>

<script>
    function applyFilters() {
        const q      = document.getElementById('searchInput').value.toLowerCase();
        const role   = document.getElementById('filterRole').value.toLowerCase();
        const status = document.getElementById('filterStatus').value.toLowerCase();
        let visible  = 0;

        document.querySelectorAll('#usersTable tbody tr').forEach(row => {
            const text        = row.textContent.toLowerCase();
            const matchText   = !q || text.includes(q);
            const matchRole   = !role || text.includes(role);
            const matchStatus = !status || text.includes(status);
            const show = matchText && matchRole && matchStatus;
            row.style.display = show ? '' : 'none';
            if (show) visible++;
        });

        document.getElementById('visibleCount').textContent = visible;
    }

    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('filterRole').addEventListener('change', applyFilters);
    document.getElementById('filterStatus').addEventListener('change', applyFilters);
</script>

<?= $this->endSection() ?>
