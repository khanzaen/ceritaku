

<?php
// Include login modal
include 'login_modal.php';

// Include register modal
include 'register_modal.php';
?>

<!-- Include auth JavaScript -->
<script src="<?= base_url('assets/js/auth.js') ?>"></script>
