<?php
/**
 * Footer file untuk CeritaKu
 * Include file ini di bagian bawah setiap halaman
 */
?>

<footer class="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-16 mt-20">
  <div class="max-w-6xl mx-auto px-6">
    <div class="grid grid-cols-1 md:grid-cols-5 gap-12 mb-12">
      <!-- Brand Section -->
      <div class="md:col-span-2">
        <a href="<?= base_url('/') ?>" class="inline-block mb-6">
          <img src="<?= base_url('assets/images/logo.png') ?>" alt="CeritaKu" class="h-12 object-contain" />
        </a>
        <div class="flex gap-3">
          <a href="mailto:info@ceritaku.com" class="w-10 h-10 bg-slate-800 hover:bg-accent text-white rounded-full transition-colors flex items-center justify-center" aria-label="Email">
            <span class="material-symbols-outlined text-xl">mail</span>
          </a>
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" class="w-10 h-10 bg-slate-800 hover:bg-accent text-white rounded-full transition-colors flex items-center justify-center" aria-label="Facebook">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
          </a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" class="w-10 h-10 bg-slate-800 hover:bg-accent text-white rounded-full transition-colors flex items-center justify-center" aria-label="Instagram">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
          </a>
          <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" class="w-10 h-10 bg-slate-800 hover:bg-accent text-white rounded-full transition-colors flex items-center justify-center" aria-label="TikTok">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
            </svg>
          </a>
        </div>
      </div>

      <!-- Discover Column -->
      <div>
        <h6 class="text-xs font-bold uppercase tracking-widest text-accent mb-6">Jelajahi</h6>
        <ul class="space-y-3 text-sm text-slate-300">
          <li><a class="hover:text-accent transition-colors" href="./discover.php">Browse Stories</a></li>
          <li><a class="hover:text-accent transition-colors" href="./discover.php">Top Picks</a></li>
          <li><a class="hover:text-accent transition-colors" href="./discover.php">Trending</a></li>
          <li><a class="hover:text-accent transition-colors" href="./reviews.php">Reviews</a></li>
        </ul>
      </div>

      <!-- For Authors Column -->
      <div>
        <h6 class="text-xs font-bold uppercase tracking-widest text-accent mb-6">Untuk Penulis</h6>
        <ul class="space-y-3 text-sm text-slate-300">
          <li><a class="hover:text-accent transition-colors" href="./write.php">Tulis Cerita</a></li>
          <li><a class="hover:text-accent transition-colors" href="./create_story.php">Publikasikan</a></li>
          <li><a class="hover:text-accent transition-colors" href="#">Dashboard</a></li>
          <li><a class="hover:text-accent transition-colors" href="#">Monetisasi</a></li>
        </ul>
      </div>

      <!-- Support Column -->
      <div>
        <h6 class="text-xs font-bold uppercase tracking-widest text-accent mb-6">Bantuan</h6>
        <ul class="space-y-3 text-sm text-slate-300">
          <li><a class="hover:text-accent transition-colors" href="#">Tentang Kami</a></li>
          <li><a class="hover:text-accent transition-colors" href="#">Kebijakan</a></li>
          <li><a class="hover:text-accent transition-colors" href="#">Hubungi Kami</a></li>
          <li><a class="hover:text-accent transition-colors" href="#">FAQ</a></li>
        </ul>
      </div>
    </div>

    <!-- Divider -->
    <div class="border-t border-slate-700 pt-8">
      <div class="flex flex-col md:flex-row justify-between items-center gap-6">
        <p class="text-slate-400 text-xs font-medium">© 2026 CeritaKu. Semua hak dilindungi. Platform literatur independen Indonesia.</p>
        <div class="flex gap-8 text-slate-400 text-xs">
          <a href="#" class="hover:text-accent transition-colors">Privacy Policy</a>
          <a href="#" class="hover:text-accent transition-colors">Terms of Service</a>
          <a href="#" class="hover:text-accent transition-colors">Cookie Settings</a>
        </div>
      </div>
    </div>
  </div>
</footer>

<script src="./js/main.js"></script>
</body></html>
